#include<cstdio>
#include"bintree1.h"
#include<utility>
using namespace std;

int main(){
	setvbuf(stdin, new char[1 << 20], _IOFBF, 1 << 20);
    setvbuf(stdout, new char[1 << 20], _IOFBF, 1 << 20);
	freopen("G:\\������\\C++\\�ھ����ϻ�\\ConsoleApplication2\\ConsoleApplication2\\a.txt", "r", stdin);
	//freopen("G:\\������\\���ݽṹ\\Դ�ļ�\\PA3\\luzhouyue.txt", "w", stdout);
    int n, m;
    scanf("%d%d", &n, &m);
    Vector< pair<int, int> > Bridge(n, n); 
    Vector< pair<int, int> > Material(m, m);
    for(int i=0; i<n; i++)
    	scanf("%d%d", &Bridge[i].second, &Bridge[i].first);
    for(int i=0; i<m; i++)
    	scanf("%d%d", &Material[i].second, &Material[i].first);
    Bridge.sort();
	
    Material.sort();
	
    long long int totalCost = 0;
    BinTree<int> Mytree;
    int index = m-1;
    for(int i=n-1; 0<=i; i--){
		//printf("A ");
    	for(; 0<=index; index--){
    		if( Bridge[i].first <= Material[index].first )
    			if( !Mytree.empty() ) Mytree.insert( Material[index].second );
    		    else Mytree.insertAsRoot( Material[index].second );
    		else break;
		    //printf("B ");
    	}
    	BinNodePosi(int) posi = Mytree.searchLower( Bridge[i].second );
		//if(!posi) printf("false\n");
		//printf("%d ",posi->data);
    	totalCost += posi->data;
    	Mytree.remove( posi->data);
    }
	//printf("\n");
    printf("%lld", totalCost);
    return 0;
}