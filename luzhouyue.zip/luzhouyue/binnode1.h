#ifndef BINNODE1_H
#define BINNODE1_H
#include"queue.h"
#include"stack.h"
#include"binnode_implement.h"
template <typename T> struct BinNode { //二叉树节点模板类
   T data; //数值
   int count; //记录点的数目
   int height; //高度（通用）
   BinNodePosi(T) parent; BinNodePosi(T) lc; BinNodePosi(T) rc; //父节点及左、右孩子
// 构造函数
   BinNode() :
      parent ( NULL ), lc ( NULL ), rc ( NULL ), height ( 0 ), count ( 0 ){ }
   BinNode ( T e,  int c = 1, int h = 0, BinNodePosi(T) p = NULL, BinNodePosi(T) lc = NULL, BinNodePosi(T) rc = NULL)
      :data ( e ), parent ( p ), lc ( lc ), rc ( rc ), height ( h ), count ( c ){ }
// 操作接口
   int size(); //统计当前节点后代总数，亦即以其为根的子树的规模
   BinNodePosi(T) insertAsLC ( T const& ); //作为当前节点的左孩子插入新节点
   BinNodePosi(T) insertAsRC ( T const& ); //作为当前节点的右孩子插入新节点
   BinNodePosi(T) succ(); //取当前节点的直接后继
   bool operator< ( BinNode const& bn ) { return data < bn.data; } //小于
   bool operator== ( BinNode const& bn ) { return data == bn.data; } //等于

   //BinNodePosi(T) zig(); //顺时针旋转
   //BinNodePosi(T) zag(); //逆时针旋转
};

template <typename T> int BinNode<T>::size() { //统计当前节点后代总数，即以其为根的子树规模
   int s = 1; //计入本身
   if ( lc ) s += lc->size(); //递归计入左子树规模
   if ( rc ) s += rc->size(); //递归计入右子树规模
   return s;
}

template <typename T> BinNodePosi(T) BinNode<T>::insertAsLC ( T const& e )
{ return lc = new BinNode ( e, 1, 0, this ); } //将e作为当前节点的左孩子插入二叉树

template <typename T> BinNodePosi(T) BinNode<T>::insertAsRC ( T const& e )
{ return rc = new BinNode ( e, 1, 0, this ); } //将e作为当前节点的右孩子插入二叉树

template <typename T> BinNodePosi(T) BinNode<T>::succ() { //定位节点v的直接后继
   BinNodePosi(T) s = this; //记录后继的临时变量
   if ( rc ) { //若有右孩子，则直接后继必在右子树中，具体地就是
      s = rc; //右子树中
      while ( HasLChild ( *s ) ) s = s->lc; //最靠左（最小）的节点
   } else { //否则，直接后继应是“将当前节点包含于其左子树中的最低祖先”，具体地就是
      while ( IsRChild ( *s ) ) s = s->parent; //逆向地沿右向分支，不断朝左上方移动
      s = s->parent; //最后再朝右上方移动一步，即抵达直接后继（如果存在）
   }
   return s;
}

/*template <typename T> BinNodePosi(T) BinNode<T>::zig() { //顺时针旋转
   BinNodePosi(T) lChild = lc;
   lChild->parent = this->parent;
   if ( lChild->parent )
      ( ( this == lChild->parent->rc ) ? lChild->parent->rc : lChild->parent->lc ) = lChild;
   lc = lChild->rc; if ( lc ) lc->parent = this;
   lChild->rc = this; this->parent = lChild;
// update heights ()
   height = 1 + max ( stature ( lc ), stature ( rc ) );
   lChild->height = 1 + max ( stature ( lChild->lc ), stature ( lChild->rc ) );
   for ( BinNodePosi(T) x = lChild->parent; x; x = x->parent )
      if ( HeightUpdated( *x ) )
         break;
      else
         x->height = 1 + max ( stature ( x->lc ), stature ( x->rc ) );
   return lChild;
}

template <typename T> BinNodePosi(T) BinNode<T>::zag() { //逆时针旋转
   BinNodePosi(T) rChild = rc;
   rChild->parent = this->parent;
   if ( rChild->parent )
      ( ( this == rChild->parent->lc ) ? rChild->parent->lc : rChild->parent->rc ) = rChild;
   rc = rChild->lc; if ( rc ) rc->parent = this;
   rChild->lc = this; this->parent = rChild;
// update heights
   height = 1 + max ( stature ( lc ), stature ( rc ) );
   rChild->height = 1 + max ( stature ( rChild->lc ), stature ( rChild->rc ) );
   for ( BinNodePosi(T) x = rChild->parent; x; x = x->parent )
      if ( HeightUpdated( *x ) )
         break;
      else
         x->height = 1 + max ( stature ( x->lc ), stature ( x->rc ) );
   return rChild;
}*/

#endif